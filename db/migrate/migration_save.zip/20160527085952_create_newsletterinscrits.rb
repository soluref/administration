class CreateNewsletterinscrits < ActiveRecord::Migration
  def change
    create_table :newsletterinscrits do |t|

      t.timestamps null: false
    end
  end
end
