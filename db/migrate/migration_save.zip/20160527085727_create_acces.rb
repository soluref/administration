class CreateAcces < ActiveRecord::Migration
  def change
    create_table :acces do |t|

      t.timestamps null: false
    end
  end
end
